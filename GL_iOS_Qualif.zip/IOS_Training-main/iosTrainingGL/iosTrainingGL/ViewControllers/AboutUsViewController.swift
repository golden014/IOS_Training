//
//  AboutUsViewController.swift
//  iosTrainingGL
//
//  Created by prk on 5/2/23.
//

import UIKit

class AboutUsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logoutClicked(_ sender: Any) {
        print("masuk")
        if let nextView = storyboard?.instantiateViewController(withIdentifier: "SplashScreen") {
            navigationController?.pushViewController(nextView, animated: true)
        } else {
            print("faill")
        }
    
        print("hmm")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
